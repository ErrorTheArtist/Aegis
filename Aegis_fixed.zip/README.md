# Aegis Discord Bot

## Render Setup
Build Command:
pip install -r requirements.txt

Start Command:
cd bot && python main.py

Environment Variable:
DISCORD_TOKEN=your_bot_token
