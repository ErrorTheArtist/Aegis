import discord
from discord.ext import commands
import asyncio
import datetime
import logging
import sys
import os
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import database as db

logger = logging.getLogger("bot.antinuke")

action_log: dict[int, dict[int, list]] = defaultdict(lambda: defaultdict(list))

THRESHOLDS = {
    "ban": 3,
    "kick": 3,
    "channel_delete": 3,
    "channel_create": 5,
    "role_delete": 3,
    "role_create": 5,
    "webhook_create": 3,
}

WINDOW = 10


def record_action(guild_id: int, user_id: int, action: str) -> int:
    now = datetime.datetime.utcnow()
    log = action_log[guild_id][user_id]
    log.append({"action": action, "time": now})
    cutoff = now - datetime.timedelta(seconds=WINDOW)
    action_log[guild_id][user_id] = [
        e for e in log if e["time"] > cutoff and e["action"] == action
    ]
    return len(action_log[guild_id][user_id])


async def punish(guild: discord.Guild, user_id: int, reason: str, bot: commands.Bot):
    logger.warning(f"Anti-nuke triggered in {guild}: punishing {user_id} — {reason}")

    db.add_log(guild.id, "antinuke_punish", user_id=user_id, reason=reason,
               moderator_name="Anti-Nuke System")

    member = guild.get_member(user_id)
    if member:
        try:
            await member.ban(reason=f"[Anti-Nuke] {reason}", delete_message_days=0)
        except discord.Forbidden:
            logger.error(f"Could not ban {user_id}: missing permissions")

    log_channel_id = db.get_setting(guild.id, "antinuke_log_channel")
    if log_channel_id:
        channel = guild.get_channel(int(log_channel_id))
        if channel:
            embed = discord.Embed(
                title="🛡️ Anti-Nuke Triggered",
                color=discord.Color.dark_red(),
                description=f"**Action:** {reason}\n**User:** <@{user_id}> (`{user_id}`)",
                timestamp=datetime.datetime.utcnow()
            )
            embed.set_footer(text="Anti-Nuke System")
            await channel.send(embed=embed)


class AntiNuke(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_and_punish(self, guild: discord.Guild, user_id: int, action: str):
        enabled = db.get_setting(guild.id, "antinuke_enabled", "0")
        if enabled != "1":
            return
        if db.is_whitelisted(guild.id, user_id):
            return
        if user_id == guild.owner_id:
            return
        if user_id == self.bot.user.id:
            return

        count = record_action(guild.id, user_id, action)
        threshold = THRESHOLDS.get(action, 3)
        if count >= threshold:
            await punish(
                guild, user_id,
                f"Exceeded {action} threshold ({count}/{threshold} in {WINDOW}s)",
                self.bot
            )

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.ban):
            if entry.user:
                await self.check_and_punish(guild, entry.user.id, "ban")
            break

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        guild = member.guild
        await asyncio.sleep(0.5)
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.kick):
            if entry.target and entry.target.id == member.id and entry.user:
                await self.check_and_punish(guild, entry.user.id, "kick")
            break

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
            if entry.user:
                await self.check_and_punish(guild, entry.user.id, "channel_delete")
            break

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create):
            if entry.user:
                await self.check_and_punish(guild, entry.user.id, "channel_create")
            break

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        guild = role.guild
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete):
            if entry.user:
                await self.check_and_punish(guild, entry.user.id, "role_delete")
            break

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        guild = role.guild
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.role_create):
            if entry.user:
                await self.check_and_punish(guild, entry.user.id, "role_create")
            break

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.webhook_create):
            if entry.user:
                await self.check_and_punish(guild, entry.user.id, "webhook_create")
            break

    @commands.group(name="antinuke", invoke_without_command=True)
    @commands.has_permissions(administrator=True)
    async def antinuke_group(self, ctx):
        enabled = db.get_setting(ctx.guild.id, "antinuke_enabled", "0") == "1"
        whitelist_ids = db.get_whitelist(ctx.guild.id)
        whitelist_str = ", ".join(f"<@{uid}>" for uid in whitelist_ids) or "None"
        log_channel_id = db.get_setting(ctx.guild.id, "antinuke_log_channel")
        log_channel_str = f"<#{log_channel_id}>" if log_channel_id else "Not set"

        embed = discord.Embed(
            title="🛡️ Anti-Nuke Status",
            color=discord.Color.blue() if enabled else discord.Color.greyple()
        )
        embed.add_field(name="Status", value="✅ Enabled" if enabled else "❌ Disabled", inline=False)
        embed.add_field(name="Log Channel", value=log_channel_str, inline=False)
        embed.add_field(name="Whitelisted Users", value=whitelist_str, inline=False)
        embed.add_field(
            name=f"Thresholds (per {WINDOW}s)",
            value="\n".join(f"`{k}`: {v}" for k, v in THRESHOLDS.items()),
            inline=False
        )
        await ctx.send(embed=embed)

    @antinuke_group.command(name="enable")
    @commands.has_permissions(administrator=True)
    async def antinuke_enable(self, ctx):
        db.set_setting(ctx.guild.id, "antinuke_enabled", "1")
        await ctx.send("✅ Anti-nuke **enabled**. The bot will now monitor and act on suspicious activity.")

    @antinuke_group.command(name="disable")
    @commands.has_permissions(administrator=True)
    async def antinuke_disable(self, ctx):
        db.set_setting(ctx.guild.id, "antinuke_enabled", "0")
        await ctx.send("❌ Anti-nuke **disabled**.")

    @antinuke_group.command(name="whitelist")
    @commands.has_permissions(administrator=True)
    async def antinuke_whitelist(self, ctx, member: discord.Member):
        db.add_to_whitelist(ctx.guild.id, member.id)
        await ctx.send(f"✅ **{member}** has been whitelisted from anti-nuke checks.")

    @antinuke_group.command(name="unwhitelist")
    @commands.has_permissions(administrator=True)
    async def antinuke_unwhitelist(self, ctx, member: discord.Member):
        db.remove_from_whitelist(ctx.guild.id, member.id)
        await ctx.send(f"✅ **{member}** has been removed from the anti-nuke whitelist.")

    @antinuke_group.command(name="logchannel")
    @commands.has_permissions(administrator=True)
    async def antinuke_logchannel(self, ctx, channel: discord.TextChannel):
        db.set_setting(ctx.guild.id, "antinuke_log_channel", str(channel.id))
        await ctx.send(f"✅ Anti-nuke alerts will be sent to {channel.mention}.")

    @antinuke_group.command(name="thresholds")
    async def antinuke_thresholds(self, ctx):
        embed = discord.Embed(
            title="🛡️ Anti-Nuke Thresholds",
            description=f"Actions are counted over a **{WINDOW}-second** rolling window.",
            color=discord.Color.blue()
        )
        for action, threshold in THRESHOLDS.items():
            embed.add_field(name=action.replace("_", " ").title(), value=f"{threshold} actions", inline=True)
        await ctx.send(embed=embed)

    @antinuke_group.error
    async def antinuke_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need Administrator permission to manage anti-nuke settings.")


async def setup(bot):
    await bot.add_cog(AntiNuke(bot))
