import discord
from discord.ext import commands
import asyncio
import datetime
import logging
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import database as db

logger = logging.getLogger("bot.moderation")


def parse_duration(duration_str: str) -> int:
    """Parse duration string like '10m', '2h', '1d' to seconds."""
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    unit = duration_str[-1].lower()
    if unit not in units:
        raise ValueError(f"Invalid duration unit: {unit}. Use s, m, h, or d.")
    try:
        value = int(duration_str[:-1])
    except ValueError:
        raise ValueError(f"Invalid duration value: {duration_str[:-1]}")
    return value * units[unit]


class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def check_hierarchy(self, ctx, member: discord.Member) -> bool:
        return ctx.author.top_role > member.top_role and ctx.guild.me.top_role > member.top_role

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        if not self.check_hierarchy(ctx, member):
            return await ctx.send("❌ You cannot ban this user due to role hierarchy.")
        await member.ban(reason=f"{ctx.author}: {reason}")
        db.add_log(ctx.guild.id, "ban", user_id=member.id, reason=reason,
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        embed = discord.Embed(
            title="🔨 Member Banned",
            color=discord.Color.red(),
            description=f"**{member}** has been banned."
        )
        embed.add_field(name="Reason", value=reason)
        embed.add_field(name="Moderator", value=ctx.author.mention)
        await ctx.send(embed=embed)
        logger.info(f"{ctx.author} banned {member} in {ctx.guild}: {reason}")

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, user_id: int):
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user)
            db.add_log(ctx.guild.id, "unban", user_id=user.id,
                       moderator_id=ctx.author.id, moderator_name=str(ctx.author))
            embed = discord.Embed(
                title="✅ Member Unbanned",
                color=discord.Color.green(),
                description=f"**{user}** has been unbanned."
            )
            await ctx.send(embed=embed)
        except discord.NotFound:
            await ctx.send("❌ User not found or not banned.")

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        if not self.check_hierarchy(ctx, member):
            return await ctx.send("❌ You cannot kick this user due to role hierarchy.")
        await member.kick(reason=f"{ctx.author}: {reason}")
        db.add_log(ctx.guild.id, "kick", user_id=member.id, reason=reason,
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        embed = discord.Embed(
            title="👢 Member Kicked",
            color=discord.Color.orange(),
            description=f"**{member}** has been kicked."
        )
        embed.add_field(name="Reason", value=reason)
        embed.add_field(name="Moderator", value=ctx.author.mention)
        await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def mute(self, ctx, member: discord.Member, duration: str = "10m", *, reason: str = "No reason provided"):
        if not self.check_hierarchy(ctx, member):
            return await ctx.send("❌ You cannot mute this user due to role hierarchy.")
        try:
            seconds = parse_duration(duration)
        except ValueError as e:
            return await ctx.send(f"❌ {e}")
        until = discord.utils.utcnow() + datetime.timedelta(seconds=seconds)
        await member.timeout(until, reason=f"{ctx.author}: {reason}")
        db.add_log(ctx.guild.id, "mute", user_id=member.id, reason=f"{duration} — {reason}",
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        embed = discord.Embed(
            title="🔇 Member Muted",
            color=discord.Color.orange(),
            description=f"**{member}** has been timed out for **{duration}**."
        )
        embed.add_field(name="Reason", value=reason)
        embed.add_field(name="Expires", value=f"<t:{int(until.timestamp())}:R>")
        embed.add_field(name="Moderator", value=ctx.author.mention)
        await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def unmute(self, ctx, member: discord.Member):
        await member.timeout(None)
        db.add_log(ctx.guild.id, "unmute", user_id=member.id,
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        embed = discord.Embed(
            title="🔊 Member Unmuted",
            color=discord.Color.green(),
            description=f"**{member}**'s timeout has been removed."
        )
        await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def warn(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        count = db.add_warning(
            ctx.guild.id, member.id, reason,
            ctx.author.id, str(ctx.author)
        )
        db.add_log(ctx.guild.id, "warn", user_id=member.id, reason=reason,
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        embed = discord.Embed(
            title="⚠️ Member Warned",
            color=discord.Color.yellow(),
            description=f"**{member}** has been warned. (Warning #{count})"
        )
        embed.add_field(name="Reason", value=reason)
        embed.add_field(name="Moderator", value=ctx.author.mention)
        await ctx.send(embed=embed)
        try:
            await member.send(
                f"⚠️ You have been warned in **{ctx.guild.name}**.\n"
                f"**Reason:** {reason}\nThis is warning #{count}."
            )
        except discord.Forbidden:
            pass

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def warnings(self, ctx, member: discord.Member):
        rows = db.get_warnings(ctx.guild.id, member.id)
        if not rows:
            return await ctx.send(f"✅ **{member}** has no warnings.")
        embed = discord.Embed(
            title=f"⚠️ Warnings for {member}",
            color=discord.Color.yellow()
        )
        for i, w in enumerate(rows, 1):
            embed.add_field(
                name=f"Warning #{i}",
                value=f"**Reason:** {w['reason']}\n**By:** {w['moderator_name']}\n**When:** {w['timestamp'][:10]}",
                inline=False
            )
        await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def clearwarn(self, ctx, member: discord.Member):
        db.clear_warnings(ctx.guild.id, member.id)
        db.add_log(ctx.guild.id, "clearwarn", user_id=member.id,
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        await ctx.send(f"✅ Cleared all warnings for **{member}**.")

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int):
        if amount < 1 or amount > 500:
            return await ctx.send("❌ Amount must be between 1 and 500.")
        deleted = await ctx.channel.purge(limit=amount + 1)
        db.add_log(ctx.guild.id, "purge", reason=f"{len(deleted) - 1} messages in #{ctx.channel.name}",
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        msg = await ctx.send(f"🗑️ Deleted **{len(deleted) - 1}** messages.")
        await asyncio.sleep(3)
        await msg.delete()

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def slowmode(self, ctx, seconds: int):
        if seconds < 0 or seconds > 21600:
            return await ctx.send("❌ Slowmode must be between 0 and 21600 seconds.")
        await ctx.channel.edit(slowmode_delay=seconds)
        db.add_log(ctx.guild.id, "slowmode", reason=f"{seconds}s in #{ctx.channel.name}",
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        if seconds == 0:
            await ctx.send("✅ Slowmode disabled.")
        else:
            await ctx.send(f"✅ Slowmode set to **{seconds}** seconds.")

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def lock(self, ctx):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = False
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        db.add_log(ctx.guild.id, "lock", reason=f"#{ctx.channel.name}",
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        await ctx.send("🔒 Channel locked.")

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, ctx):
        overwrite = ctx.channel.overwrites_for(ctx.guild.default_role)
        overwrite.send_messages = True
        await ctx.channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
        db.add_log(ctx.guild.id, "unlock", reason=f"#{ctx.channel.name}",
                   moderator_id=ctx.author.id, moderator_name=str(ctx.author))
        await ctx.send("🔓 Channel unlocked.")

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def modlogs(self, ctx, member: discord.Member = None):
        if member:
            rows = db.get_logs(ctx.guild.id, limit=20, action=None)
            rows = [r for r in rows if r["user_id"] == member.id]
            title = f"📋 Mod Logs — {member}"
        else:
            rows = db.get_logs(ctx.guild.id, limit=15)
            title = f"📋 Recent Mod Logs — {ctx.guild.name}"

        if not rows:
            return await ctx.send("No logs found.")

        embed = discord.Embed(title=title, color=discord.Color.blurple())
        for row in rows[:10]:
            value = f"**By:** {row['moderator_name'] or 'System'}"
            if row["reason"]:
                value += f"\n**Reason:** {row['reason']}"
            value += f"\n**When:** {row['timestamp'][:16].replace('T', ' ')} UTC"
            embed.add_field(
                name=f"[{row['action'].upper()}] — <@{row['user_id']}>",
                value=value,
                inline=False
            )
        await ctx.send(embed=embed)

    @ban.error
    @kick.error
    @mute.error
    @unmute.error
    @purge.error
    @slowmode.error
    @lock.error
    @unlock.error
    async def mod_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You don't have permission to use this command.")
        elif isinstance(error, commands.MemberNotFound):
            await ctx.send("❌ Member not found.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"❌ Missing argument: `{error.param.name}`")
        else:
            logger.error(f"Moderation command error: {error}")
            await ctx.send(f"❌ An error occurred: {error}")


async def setup(bot):
    await bot.add_cog(Moderation(bot))
