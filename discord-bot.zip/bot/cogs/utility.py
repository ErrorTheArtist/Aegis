import discord
from discord.ext import commands
import datetime
import platform
import logging

logger = logging.getLogger("bot.utility")

start_time = datetime.datetime.utcnow()


class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ping(self, ctx):
        latency = round(self.bot.latency * 1000)
        color = discord.Color.green() if latency < 100 else (
            discord.Color.yellow() if latency < 200 else discord.Color.red()
        )
        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"Latency: **{latency}ms**",
            color=color
        )
        await ctx.send(embed=embed)

    @commands.command()
    async def uptime(self, ctx):
        now = datetime.datetime.utcnow()
        delta = now - start_time
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days = delta.days
        embed = discord.Embed(
            title="⏱️ Bot Uptime",
            color=discord.Color.blurple()
        )
        embed.add_field(name="Uptime", value=f"{days}d {hours % 24}h {minutes}m {seconds}s")
        embed.add_field(name="Online Since", value=f"<t:{int(start_time.timestamp())}:F>")
        await ctx.send(embed=embed)

    @commands.command()
    async def userinfo(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        roles = [r.mention for r in reversed(member.roles) if r != ctx.guild.default_role]

        embed = discord.Embed(
            title=f"👤 User Info — {member}",
            color=member.color if member.color.value else discord.Color.blurple()
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="ID", value=member.id)
        embed.add_field(name="Nickname", value=member.nick or "None")
        embed.add_field(name="Bot", value="Yes" if member.bot else "No")
        embed.add_field(
            name="Account Created",
            value=f"<t:{int(member.created_at.timestamp())}:F>"
        )
        embed.add_field(
            name="Joined Server",
            value=f"<t:{int(member.joined_at.timestamp())}:F>" if member.joined_at else "Unknown"
        )
        embed.add_field(
            name=f"Roles [{len(roles)}]",
            value=" ".join(roles[:10]) + ("..." if len(roles) > 10 else "") or "None",
            inline=False
        )
        if member.premium_since:
            embed.add_field(
                name="Boosting Since",
                value=f"<t:{int(member.premium_since.timestamp())}:F>"
            )
        await ctx.send(embed=embed)

    @commands.command()
    async def serverinfo(self, ctx):
        guild = ctx.guild
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        categories = len(guild.categories)
        bots = sum(1 for m in guild.members if m.bot)
        humans = guild.member_count - bots

        embed = discord.Embed(
            title=f"🏠 Server Info — {guild.name}",
            color=discord.Color.blurple()
        )
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Owner", value=guild.owner.mention if guild.owner else "Unknown")
        embed.add_field(name="ID", value=guild.id)
        embed.add_field(
            name="Created",
            value=f"<t:{int(guild.created_at.timestamp())}:F>"
        )
        embed.add_field(name="Members", value=f"👤 {humans} humans | 🤖 {bots} bots")
        embed.add_field(
            name="Channels",
            value=f"💬 {text_channels} text | 🔊 {voice_channels} voice | 📁 {categories} categories"
        )
        embed.add_field(name="Roles", value=len(guild.roles))
        embed.add_field(name="Boost Level", value=f"Level {guild.premium_tier} ({guild.premium_subscription_count} boosts)")
        embed.add_field(name="Verification Level", value=str(guild.verification_level).title())
        if guild.banner:
            embed.set_image(url=guild.banner.url)
        await ctx.send(embed=embed)

    @commands.command()
    async def avatar(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        embed = discord.Embed(
            title=f"🖼️ Avatar — {member}",
            color=discord.Color.blurple()
        )
        embed.set_image(url=member.display_avatar.url)
        embed.add_field(
            name="Links",
            value=f"[PNG]({member.display_avatar.with_format('png').url}) | "
                  f"[JPG]({member.display_avatar.with_format('jpg').url}) | "
                  f"[WEBP]({member.display_avatar.with_format('webp').url})"
        )
        await ctx.send(embed=embed)

    @commands.command()
    async def roleinfo(self, ctx, *, role: discord.Role):
        members_with_role = len(role.members)
        embed = discord.Embed(
            title=f"🎭 Role Info — {role.name}",
            color=role.color if role.color.value else discord.Color.default()
        )
        embed.add_field(name="ID", value=role.id)
        embed.add_field(name="Color", value=str(role.color))
        embed.add_field(name="Members", value=members_with_role)
        embed.add_field(name="Mentionable", value="Yes" if role.mentionable else "No")
        embed.add_field(name="Hoisted", value="Yes" if role.hoist else "No")
        embed.add_field(name="Position", value=role.position)
        embed.add_field(
            name="Created",
            value=f"<t:{int(role.created_at.timestamp())}:F>"
        )
        key_perms = []
        perms = role.permissions
        perm_map = {
            "administrator": "Administrator",
            "manage_guild": "Manage Server",
            "manage_channels": "Manage Channels",
            "manage_roles": "Manage Roles",
            "manage_messages": "Manage Messages",
            "kick_members": "Kick Members",
            "ban_members": "Ban Members",
            "mention_everyone": "Mention Everyone",
        }
        for perm, label in perm_map.items():
            if getattr(perms, perm, False):
                key_perms.append(label)
        if key_perms:
            embed.add_field(name="Key Permissions", value=", ".join(key_perms), inline=False)
        await ctx.send(embed=embed)

    @commands.command()
    async def channelinfo(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        embed = discord.Embed(
            title=f"📋 Channel Info — #{channel.name}",
            color=discord.Color.blurple()
        )
        embed.add_field(name="ID", value=channel.id)
        embed.add_field(name="Category", value=channel.category.name if channel.category else "None")
        embed.add_field(name="NSFW", value="Yes" if channel.is_nsfw() else "No")
        embed.add_field(name="Slowmode", value=f"{channel.slowmode_delay}s")
        embed.add_field(
            name="Created",
            value=f"<t:{int(channel.created_at.timestamp())}:F>"
        )
        if channel.topic:
            embed.add_field(name="Topic", value=channel.topic, inline=False)
        await ctx.send(embed=embed)

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def say(self, ctx, *, message: str):
        await ctx.message.delete()
        await ctx.send(message)

    @userinfo.error
    @avatar.error
    @roleinfo.error
    @channelinfo.error
    async def utility_error(self, ctx, error):
        if isinstance(error, commands.MemberNotFound):
            await ctx.send("❌ Member not found.")
        elif isinstance(error, commands.RoleNotFound):
            await ctx.send("❌ Role not found.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"❌ Missing argument: `{error.param.name}`")
        else:
            logger.error(f"Utility command error: {error}")
            await ctx.send(f"❌ An error occurred: {error}")


async def setup(bot):
    await bot.add_cog(Utility(bot))
