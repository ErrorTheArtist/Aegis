import os
import threading
import logging
from flask import Flask, request, jsonify, session, redirect, url_for, render_template, abort
from flask_cors import CORS
import database as db

logger = logging.getLogger("bot.dashboard")

_bot_ref = None


def get_bot():
    return _bot_ref


def create_app(bot) -> Flask:
    global _bot_ref
    _bot_ref = bot

    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.secret_key = os.environ.get("SESSION_SECRET", "change-me-in-production")
    CORS(app, supports_credentials=True)

    DASHBOARD_PASSWORD = os.environ.get("DASHBOARD_PASSWORD", "admin")

    # ── Auth helpers ──────────────────────────────────────────────────────────

    def require_auth():
        if not session.get("authenticated"):
            if request.path.startswith("/api/"):
                abort(401)
            return redirect(url_for("login_page"))
        return None

    # ── Pages ─────────────────────────────────────────────────────────────────

    @app.route("/")
    def index():
        if not session.get("authenticated"):
            return redirect(url_for("login_page"))
        return render_template("index.html")

    @app.route("/login", methods=["GET"])
    def login_page():
        if session.get("authenticated"):
            return redirect(url_for("index"))
        return render_template("login.html")

    @app.route("/api/login", methods=["POST"])
    def api_login():
        data = request.get_json() or {}
        if data.get("password") == DASHBOARD_PASSWORD:
            session["authenticated"] = True
            return jsonify({"ok": True})
        return jsonify({"ok": False, "error": "Invalid password"}), 401

    @app.route("/api/logout", methods=["POST"])
    def api_logout():
        session.clear()
        return jsonify({"ok": True})

    # ── Guilds ────────────────────────────────────────────────────────────────

    @app.route("/api/guilds")
    def api_guilds():
        redir = require_auth()
        if redir:
            return redir
        b = get_bot()
        guilds = []
        if b:
            for g in b.guilds:
                guilds.append({
                    "id": str(g.id),
                    "name": g.name,
                    "icon": str(g.icon.url) if g.icon else None,
                    "member_count": g.member_count,
                })
        return jsonify(guilds)

    # ── Settings ──────────────────────────────────────────────────────────────

    @app.route("/api/guild/<int:guild_id>/settings", methods=["GET"])
    def api_get_settings(guild_id):
        redir = require_auth()
        if redir:
            return redir
        return jsonify({
            "prefix": db.get_setting(guild_id, "prefix", "!"),
            "antinuke_enabled": db.get_setting(guild_id, "antinuke_enabled", "0") == "1",
            "antinuke_log_channel": db.get_setting(guild_id, "antinuke_log_channel", ""),
            "mod_log_channel": db.get_setting(guild_id, "mod_log_channel", ""),
            "thresholds": {
                "ban": int(db.get_setting(guild_id, "threshold_ban", "3")),
                "kick": int(db.get_setting(guild_id, "threshold_kick", "3")),
                "channel_delete": int(db.get_setting(guild_id, "threshold_channel_delete", "3")),
                "channel_create": int(db.get_setting(guild_id, "threshold_channel_create", "5")),
                "role_delete": int(db.get_setting(guild_id, "threshold_role_delete", "3")),
                "role_create": int(db.get_setting(guild_id, "threshold_role_create", "5")),
                "webhook_create": int(db.get_setting(guild_id, "threshold_webhook_create", "3")),
            }
        })

    @app.route("/api/guild/<int:guild_id>/settings", methods=["POST"])
    def api_save_settings(guild_id):
        redir = require_auth()
        if redir:
            return redir
        data = request.get_json() or {}

        if "prefix" in data:
            prefix = str(data["prefix"]).strip() or "!"
            db.set_setting(guild_id, "prefix", prefix[:5])

        if "antinuke_enabled" in data:
            db.set_setting(guild_id, "antinuke_enabled", "1" if data["antinuke_enabled"] else "0")

        if "antinuke_log_channel" in data:
            db.set_setting(guild_id, "antinuke_log_channel", str(data["antinuke_log_channel"]).strip())

        if "mod_log_channel" in data:
            db.set_setting(guild_id, "mod_log_channel", str(data["mod_log_channel"]).strip())

        if "thresholds" in data:
            t = data["thresholds"]
            threshold_keys = [
                "ban", "kick", "channel_delete", "channel_create",
                "role_delete", "role_create", "webhook_create"
            ]
            for key in threshold_keys:
                if key in t:
                    try:
                        val = max(1, min(100, int(t[key])))
                        db.set_setting(guild_id, f"threshold_{key}", str(val))
                    except (ValueError, TypeError):
                        pass

        db.add_log(guild_id, "dashboard_settings_update",
                   moderator_name="Dashboard")
        return jsonify({"ok": True})

    # ── Whitelist ─────────────────────────────────────────────────────────────

    @app.route("/api/guild/<int:guild_id>/whitelist", methods=["GET"])
    def api_get_whitelist(guild_id):
        redir = require_auth()
        if redir:
            return redir
        ids = db.get_whitelist(guild_id)
        b = get_bot()
        result = []
        for uid in ids:
            entry = {"id": str(uid), "name": str(uid)}
            if b:
                guild = b.get_guild(guild_id)
                if guild:
                    member = guild.get_member(uid)
                    if member:
                        entry["name"] = str(member)
                        entry["avatar"] = str(member.display_avatar.url)
            result.append(entry)
        return jsonify(result)

    @app.route("/api/guild/<int:guild_id>/whitelist", methods=["POST"])
    def api_add_whitelist(guild_id):
        redir = require_auth()
        if redir:
            return redir
        data = request.get_json() or {}
        try:
            uid = int(data["user_id"])
        except (KeyError, ValueError):
            return jsonify({"ok": False, "error": "Invalid user_id"}), 400
        db.add_to_whitelist(guild_id, uid)
        return jsonify({"ok": True})

    @app.route("/api/guild/<int:guild_id>/whitelist/<int:user_id>", methods=["DELETE"])
    def api_remove_whitelist(guild_id, user_id):
        redir = require_auth()
        if redir:
            return redir
        db.remove_from_whitelist(guild_id, user_id)
        return jsonify({"ok": True})

    # ── Logs ──────────────────────────────────────────────────────────────────

    @app.route("/api/guild/<int:guild_id>/logs")
    def api_get_logs(guild_id):
        redir = require_auth()
        if redir:
            return redir
        action_filter = request.args.get("action")
        limit = min(int(request.args.get("limit", 50)), 200)
        rows = db.get_logs(guild_id, limit=limit, action=action_filter)
        return jsonify([dict(r) for r in rows])

    # ── Warnings ──────────────────────────────────────────────────────────────

    @app.route("/api/guild/<int:guild_id>/warnings/<int:user_id>", methods=["GET"])
    def api_get_warnings(guild_id, user_id):
        redir = require_auth()
        if redir:
            return redir
        rows = db.get_warnings(guild_id, user_id)
        return jsonify([dict(r) for r in rows])

    @app.route("/api/guild/<int:guild_id>/warnings/<int:user_id>", methods=["DELETE"])
    def api_clear_warnings(guild_id, user_id):
        redir = require_auth()
        if redir:
            return redir
        db.clear_warnings(guild_id, user_id)
        return jsonify({"ok": True})

    return app


def run_dashboard(bot, host="0.0.0.0", port=8080):
    app = create_app(bot)
    logger.info(f"Starting dashboard on {host}:{port}")
    app.run(host=host, port=port, debug=False, use_reloader=False)


def start_dashboard_thread(bot, port=8080):
    t = threading.Thread(
        target=run_dashboard,
        args=(bot,),
        kwargs={"port": port},
        daemon=True,
        name="dashboard"
    )
    t.start()
    logger.info("Dashboard thread started")
    return t
