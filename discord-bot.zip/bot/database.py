import sqlite3
import datetime
import os
import logging

logger = logging.getLogger("bot.database")

DB_PATH = os.path.join(os.path.dirname(__file__), "bot_data.db")


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with get_connection() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS warnings (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id    INTEGER NOT NULL,
                user_id     INTEGER NOT NULL,
                reason      TEXT    NOT NULL DEFAULT 'No reason provided',
                moderator_id   INTEGER NOT NULL,
                moderator_name TEXT    NOT NULL,
                timestamp   TEXT    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS settings (
                guild_id    INTEGER NOT NULL,
                key         TEXT    NOT NULL,
                value       TEXT    NOT NULL,
                PRIMARY KEY (guild_id, key)
            );

            CREATE TABLE IF NOT EXISTS whitelist (
                guild_id    INTEGER NOT NULL,
                user_id     INTEGER NOT NULL,
                PRIMARY KEY (guild_id, user_id)
            );

            CREATE TABLE IF NOT EXISTS logs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id    INTEGER NOT NULL,
                action      TEXT    NOT NULL,
                user_id     INTEGER,
                target_id   INTEGER,
                reason      TEXT,
                moderator_id   INTEGER,
                moderator_name TEXT,
                timestamp   TEXT    NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_warnings_guild_user ON warnings (guild_id, user_id);
            CREATE INDEX IF NOT EXISTS idx_logs_guild ON logs (guild_id);
        """)
    logger.info(f"Database initialised at {DB_PATH}")


# ── Warnings ──────────────────────────────────────────────────────────────────

def add_warning(guild_id: int, user_id: int, reason: str, moderator_id: int, moderator_name: str) -> int:
    ts = datetime.datetime.utcnow().isoformat()
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO warnings (guild_id, user_id, reason, moderator_id, moderator_name, timestamp) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (guild_id, user_id, reason, moderator_id, moderator_name, ts)
        )
    return get_warning_count(guild_id, user_id)


def get_warnings(guild_id: int, user_id: int) -> list[sqlite3.Row]:
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY id",
            (guild_id, user_id)
        ).fetchall()


def get_warning_count(guild_id: int, user_id: int) -> int:
    with get_connection() as conn:
        row = conn.execute(
            "SELECT COUNT(*) FROM warnings WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        ).fetchone()
        return row[0]


def clear_warnings(guild_id: int, user_id: int):
    with get_connection() as conn:
        conn.execute(
            "DELETE FROM warnings WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        )


# ── Settings ──────────────────────────────────────────────────────────────────

def get_setting(guild_id: int, key: str, default=None) -> str | None:
    with get_connection() as conn:
        row = conn.execute(
            "SELECT value FROM settings WHERE guild_id = ? AND key = ?",
            (guild_id, key)
        ).fetchone()
        return row["value"] if row else default


def set_setting(guild_id: int, key: str, value: str):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO settings (guild_id, key, value) VALUES (?, ?, ?) "
            "ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value",
            (guild_id, key, value)
        )


def delete_setting(guild_id: int, key: str):
    with get_connection() as conn:
        conn.execute(
            "DELETE FROM settings WHERE guild_id = ? AND key = ?",
            (guild_id, key)
        )


# ── Whitelist ─────────────────────────────────────────────────────────────────

def add_to_whitelist(guild_id: int, user_id: int):
    with get_connection() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO whitelist (guild_id, user_id) VALUES (?, ?)",
            (guild_id, user_id)
        )


def remove_from_whitelist(guild_id: int, user_id: int):
    with get_connection() as conn:
        conn.execute(
            "DELETE FROM whitelist WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        )


def get_whitelist(guild_id: int) -> list[int]:
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT user_id FROM whitelist WHERE guild_id = ?",
            (guild_id,)
        ).fetchall()
        return [row["user_id"] for row in rows]


def is_whitelisted(guild_id: int, user_id: int) -> bool:
    with get_connection() as conn:
        row = conn.execute(
            "SELECT 1 FROM whitelist WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        ).fetchone()
        return row is not None


# ── Logs ──────────────────────────────────────────────────────────────────────

def add_log(
    guild_id: int,
    action: str,
    user_id: int = None,
    target_id: int = None,
    reason: str = None,
    moderator_id: int = None,
    moderator_name: str = None,
):
    ts = datetime.datetime.utcnow().isoformat()
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO logs (guild_id, action, user_id, target_id, reason, moderator_id, moderator_name, timestamp) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (guild_id, action, user_id, target_id, reason, moderator_id, moderator_name, ts)
        )


def get_logs(guild_id: int, limit: int = 50, action: str = None) -> list[sqlite3.Row]:
    with get_connection() as conn:
        if action:
            return conn.execute(
                "SELECT * FROM logs WHERE guild_id = ? AND action = ? ORDER BY id DESC LIMIT ?",
                (guild_id, action, limit)
            ).fetchall()
        return conn.execute(
            "SELECT * FROM logs WHERE guild_id = ? ORDER BY id DESC LIMIT ?",
            (guild_id, limit)
        ).fetchall()
