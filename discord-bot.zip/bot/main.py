import discord
from discord.ext import commands
import os
import asyncio
import logging
from database import init_db, get_setting

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("bot")

COGS = [
    "cogs.moderation",
    "cogs.antinuke",
    "cogs.utility",
]

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.guilds = True
intents.bans = True


async def get_prefix(bot, message):
    if message.guild:
        return get_setting(message.guild.id, "prefix", "!")
    return "!"


bot = commands.Bot(command_prefix=get_prefix, intents=intents, help_command=None)


@bot.event
async def on_ready():
    logger.info(f"Logged in as {bot.user} (ID: {bot.user.id})")
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="over the server | !help"
        )
    )
    try:
        synced = await bot.tree.sync()
        logger.info(f"Synced {len(synced)} slash command(s)")
    except Exception as e:
        logger.error(f"Failed to sync commands: {e}")


@bot.command(name="help")
async def help_command(ctx):
    prefix = get_setting(ctx.guild.id, "prefix", "!") if ctx.guild else "!"
    embed = discord.Embed(title="Bot Commands", color=discord.Color.blurple())
    embed.add_field(
        name="🔨 Moderation",
        value=(
            f"`{prefix}ban <user> [reason]` — Ban a member\n"
            f"`{prefix}unban <user_id>` — Unban a user\n"
            f"`{prefix}kick <user> [reason]` — Kick a member\n"
            f"`{prefix}mute <user> [duration] [reason]` — Timeout a member\n"
            f"`{prefix}unmute <user>` — Remove timeout\n"
            f"`{prefix}warn <user> [reason]` — Warn a member\n"
            f"`{prefix}warnings <user>` — View warnings\n"
            f"`{prefix}clearwarn <user>` — Clear all warnings\n"
            f"`{prefix}purge <amount>` — Delete messages\n"
            f"`{prefix}slowmode <seconds>` — Set channel slowmode\n"
            f"`{prefix}lock` — Lock a channel\n"
            f"`{prefix}unlock` — Unlock a channel\n"
            f"`{prefix}modlogs [user]` — View moderation logs"
        ),
        inline=False
    )
    embed.add_field(
        name="🛡️ Anti-Nuke",
        value=(
            f"`{prefix}antinuke` — Show status\n"
            f"`{prefix}antinuke enable/disable` — Toggle protection\n"
            f"`{prefix}antinuke whitelist <user>` — Whitelist a user\n"
            f"`{prefix}antinuke logchannel #ch` — Set alert channel\n"
            f"`{prefix}antinuke thresholds` — View thresholds\n"
            f"💡 Also configurable via the web dashboard"
        ),
        inline=False
    )
    embed.add_field(
        name="🔧 Utility",
        value=(
            f"`{prefix}userinfo [user]` — User information\n"
            f"`{prefix}serverinfo` — Server information\n"
            f"`{prefix}avatar [user]` — Show avatar\n"
            f"`{prefix}roleinfo <role>` — Role information\n"
            f"`{prefix}ping` — Bot latency\n"
            f"`{prefix}uptime` — Bot uptime\n"
            f"`{prefix}channelinfo` — Channel information\n"
            f"`{prefix}say <message>` — Make bot say something"
        ),
        inline=False
    )
    embed.set_footer(text=f"Current prefix: {prefix}")
    await ctx.send(embed=embed)


async def main():
    token = os.environ.get("DISCORD_TOKEN")
    if not token:
        logger.error("DISCORD_TOKEN environment variable not set!")
        return

    init_db()

    async with bot:
        for cog in COGS:
            try:
                await bot.load_extension(cog)
                logger.info(f"Loaded cog: {cog}")
            except Exception as e:
                logger.error(f"Failed to load cog {cog}: {e}")
        await bot.start(token)


if __name__ == "__main__":
    asyncio.run(main())
